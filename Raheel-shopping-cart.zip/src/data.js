const list=[
    

{

    id: 250,
    
    name: "Apple Juice", volume: 250, inStock: true, quantity: 0,
    price: 2.99,
    
    image: 'https://media.naheed.pk/catalog/product/cache/ed9f5ebe2a117625f6cd6336daddd764/1/2/1219483-1.jpg',
    
    },
    
    {
    
    id: 250,
    
    name: "Grapes Juice", volume: 500, inStock: false, quantity: 0,
    price: 3.19,
    
    image: 'https://media.naheed.pk/catalog/product/cache/49dcd5d85f0fa4d590e132d0368d8132/1/0/1033730-1.jpg',
    
    },
    
    {
    
        id: 250,
        
        name: "Coconut Juice", volume: 500, inStock: true, quantity: 0,
        price: 5.19,
        
        image: 'https://media.naheed.pk/catalog/product/cache/49dcd5d85f0fa4d590e132d0368d8132/1/1/1179288-1.jpg',
        
        },
        {
    
            id: 250,
            
            name: "Organe Juice", volume: 500, inStock: true, quantity: 0,
            price: 1.19,
            
            image: 'https://media.naheed.pk/catalog/product/cache/49dcd5d85f0fa4d590e132d0368d8132/1/1/1166118-1.jpg',
            
            },
            {
    
                id: 250,
                
                name: "Mango Juice", volume: 250, inStock: false, quantity: 0,
                price: 4.19,
                
                image: 'https://media.naheed.pk/catalog/product/cache/49dcd5d85f0fa4d590e132d0368d8132/1/1/1166117-1.jpg',
                
                }
                    


    ]

export default list;